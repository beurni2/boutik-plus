# WO-4.2C verifier DELTA (ac83f74)

Verbatim:

---

---

## DELTA RE-VERIFICATION — ac83f74 on `e4/wo-4.2c` (delta from 031ff63)

**1. Fail-closed paths — confirmed in committed bytes and by execution.** `normalization.ts:112-118`: `base64ToBytes` now throws `ExifLeakError` on both arms — `typeof atob !== 'function'` and `b64.length === 0`. I re-ran my original vacuity probe at ac83f74: with `atob` deleted it now dies with `ExifLeakError: no base64 decoder available…` (previously printed `len = 0` and passed vacuously); direct call `base64ToBytes('')` throws `ExifLeakError: empty derivative bytes…`. My original smuggle route — `derivative.base64 ?? ''` (capture.ts:57) feeding empty bytes — now throws inside `base64ToBytes`, before `assertExifFree` is ever reached. Valid base64 still decodes correctly (5 bytes from `'SGVsbG8='`).

**2. Designed failure state — confirmed.** App.tsx:145-147: `catch { setCaptureFailed(true); }`; App.tsx:319 renders `<StatusChip tone="warn" label={t('studio.erreur')} />` on the camera screen; `studio.erreur` is in the catalog (register `neutral`, screenClass `status`), 87 entries, copy-lint clean in the full gates run. Cannot mask a real capture: `setCaptureFailed(false)` runs at the start of every `takeShot` (App.tsx:143), before the try; the chip lives only in the `pending === null` camera branch, and a successful capture moves to the preview branch.

**3. Re-run at ac83f74:** `pnpm test` **44/44** (ui-studio 18); `pnpm typecheck` **exit 0**; full `scripts/run-gates.sh` **ALL GATES GREEN** including copy-lint "87 entries, 0 violations". Mutation check: I reverted each fix in isolation (removed the empty-input throw; removed the catch) — exactly the two new regression tests failed (NB2 pin, NB3 pin), 16 others passed; restored.

**4. Carried NBs undisturbed.** `jpegCarriesExif` is byte-untouched — my full attack suite re-run at ac83f74 gives identical results (NB① fill-bytes/post-SOS gaps carried, still not plausible manipulator output). Catalog delta is the single `studio.erreur` addition — `photo.placeholder`/`photo.take` remain orphaned (NB④). The queue notice and `keepShot` are untouched (NB⑦). JOURNAL b32a3c7 contains the WO-4.2C build record including the voice-notes deferral ⚠ verbatim ("named in the row, DEFERRED ⚠… flagged, never silently dropped") — NB⑥ resolved.

VERDICT: PASS

1. **NB (new, minor)** — `reset()` (App.tsx:125-135) clears every studio state except `captureFailed`: after a failed capture, a full demo reset carries the stale « La photo n'a pas pu être prise » chip into the fresh walk's photo screen until the next `takeShot` clears it. One-line fix (`setCaptureFailed(false)` in `reset()`), can ride the next slice.
2. **NB (bookkeeping)** — ac83f74 itself is not yet journaled (JOURNAL entry b32a3c7 predates the fix commit; ac83f74 touches 5 files, none of them JOURNAL.md). The NB②/③ fix record should land in JOURNAL.md at merge.
3. **Carried from original review, unchanged by this delta:** NB① (scanner hardening — fill bytes / post-SOS), NB④ (orphaned `photo.placeholder`/`photo.take` + 4 pre-existing dead keys), NB⑤ (claim-count inaccuracies, now moot), NB⑦ (queue is notice + in-memory only; durable queue owed at B2.1).

# WO-4.2C verifier round 1 (031ff63)

Verbatim:

---

All verification complete. Writing the verdict.

---

## VERIFICATION REPORT — WO-4.2C, branch `e4/wo-4.2c` (031ff63 vs 6a3cff0)

**Evidence base (all run by me, in my clone):** `pnpm install --frozen-lockfile` clean; supplier-app `pnpm test` 42/42 across 7 files; `pnpm typecheck` 0 errors; `bash scripts/run-gates.sh` → "ALL GATES GREEN" including copy-lint "86 entries, 0 violations" and every negative fixture failing as required.

**Attack 1 — EXIF survival.** I ran my own crafted fixtures against `jpegCarriesExif` (script at scratchpad `verif42c-bp/exif-attack.mjs`): Exif APP1 after APP0+DQT → **caught**; multi-APP1 XMP-then-Exif → **caught**; Exif after APP2/ICC → **caught**; lying-length APP1 followed by Exif APP1 → **caught**; truncated header → clean (correct, no complete Exif exists). Two byte layouts defeat it — 0xFF fill bytes before the marker, and Exif appended after SOS — but neither is producible by expo-image-manipulator's re-encode (libjpeg/Skia/ImageIO writers emit contiguous header segments, no fill bytes, no trailer APP1), so by the mandate's own plausibility standard these are hardening notes, not blocks. Source level: `masterUri` appears only inside `CaptureResult`; the only `Image source` is `pending.derivative.uri` (App.tsx:328); the master is never previewed, stored separately, or published. However, the guard **fails open** on decode failure — see finding 3.

**Attack 2 — price overlay.** The action vocabulary is resize-only (`normalization.ts` `derivativeActions`/`metricsActions`; test pins `Object.keys(a) === ['resize']` and bans `.rotate(|.flip(|.crop(|.extent(` in capture.ts). No text/draw/watermark/composite API anywhere in the new paths (grep clean). Premium-frame-assets gate (EXIF-bearing + price-overlaid negatives) still fails-closed in the gates run. No injectable seam found: the derivative bytes come solely from `ImageManipulator.manipulate(masterUri)` + resize + JPEG save.

**Attack 3 — WYSIWYG.** Path traced: `takePictureAsync` → `renderDerivative` (single call, capture.ts:53) → result `{uri,width,height}` returned whole → App previews `pending.derivative.uri` → `setShots((s)=>({...s,[shot]:pending}))` stores the same object. I planted a second transform (`polished = await renderDerivative(derivative.uri,…)`) — ui-studio failed exactly on the "renders the derivative exactly once" pin (1 failed/15 passed), then restored. The metrics frame is a second render but is discarded, never previewed or stored.

**Attack 4 — budget delta, measured not trusted.** Cache-isolated exports (fresh mktemp TMPDIR/XDG_CACHE_HOME, CI=1, --source-maps), both sides:
- Base 6a3cff0: **682 modules / 1,487,520 bytes** hbc (claim said 683/1.49 MB — module count off by one).
- Branch 031ff63: **697 modules / 1,514,028 bytes** hbc.
- **Delta: +15 modules, +26,508 bytes (+1.8%) JS.**

**Ruling:** the D17 budgets (cold start < 5 s on Android Go 2GB; touch < 100 ms — docs/PERF-BUDGETS.md:20-21) are **plausibly held**: a 26 KB Hermes-bytecode delta is negligible for cold start and irrelevant to touch latency. What this container cannot measure: the native side — expo-camera/expo-image-manipulator .so size, native module registration cost, and camera HAL init time on the reference device. That must be confirmed at the next on-device matrix pass; the JS proxy alone cannot close it.

**DoD sweep.** 42/42 (ui-studio contributes **16** tests, not the claimed 14); assertions read — they pin real invariants (byte-level EXIF fixtures, action whitelist, source pins), not names. Zero-hardcode scan: planted `#ff0000` + `gap: 12` in App.tsx → both SCAN tests failed, restored. journey-spine/demo-store/preview-banner/runtime-imports test files **byte-identical** to base (`git diff` empty). Deps exactly `expo-camera ~17.0.10` + `expo-image-manipulator ~14.0.8`, matching `node_modules/expo/bundledNativeModules.json` (verified) and registry-derived in the lockfile (sha512 integrity resolutions). Catalog 86 entries, copy-lint 0 violations; all 26 new studio/categorie keys used by App.tsx or the guidance table. WALKTHROUGH step 4 matches the code (category chips on `nouveau`, hero→preuve walk, « Ce que l'acheteur verra » = `studio.apercu`, equal-weight Reprendre/Garder, queue notice, permission-refused fallback via GhostButton → offre). B1.2 hooks are identity/absent constants; no cleanup/moderation code anywhere (grep + comment-stripped test). Voice-notes deferral is stated in guidance.ts's docblock. Permission `null` → Skeleton; refused → walkable demo path. Category chips carry `minHeight: theme.touch.minTargetPx`.

VERDICT: PASS

1. **NB** — EXIF scanner can be defeated by 0xFF fill bytes before a marker (len misread as 0xFFxx, scan overshoots) and ignores post-SOS trailer segments. Not producible by the manipulator's encoders, so non-blocking; harden when B1.2 proper lands. Evidence: `apps/supplier-app/src/studio/normalization.ts:76-101`; my attack run (`fill_bytes_before_exif → false`, `exif_after_sos → false`).
2. **NB** — The EXIF guard fails **open** on decode failure: `base64ToBytes` returns empty bytes when `atob` is absent (`normalization.ts:110`, `typeof atob === 'function' ? atob(b64) : ''`) and `capture.ts:55` uses `derivative.base64 ?? ''` — either path makes `assertExifFree` vacuously pass on zero bytes. Hermes on SDK 54 provides `atob` (unverifiable in this container), but a guard this load-bearing should throw when it cannot decode. Recommend fail-closed before B2.1 publication.
3. **NB** — `takeShot` (App.tsx:137-146) is try/finally with no catch: a capture failure — including a thrown `ExifLeakError` — becomes a silent unhandled rejection with no designed error state. The guard fails closed but invisibly; "honest states are designed states."
4. **NB** — `photo.placeholder` and `photo.take` are newly orphaned in `apps/supplier-app/i18n/catalog.json` (used at base App.tsx, referenced nowhere at 031ff63). Four older keys (`product.saved_pending`, `offer.net_preview`, `offer.floor_block`, `refused.title`) are also dead, pre-existing.
5. **NB** — Claim inaccuracies: ui-studio adds 16 tests, not 14; base export measures 682 modules, not the claimed 683 (bytes match at 1.49 MB).
6. **NB** — guidance.ts:13 says the voice-notes deferral is "journaled ⚠", but JOURNAL.md has no WO-4.2C entry in this commit (`git log 6a3cff0..031ff63 -- JOURNAL.md` empty). If journaling happens at merge per repo practice, the CTO must write the ⚠ then.
7. **NB** — The "queue" is a `PendingNotice` + in-memory React state only (App.tsx:154 `setPendingKey('studio.queue_pending')`); shots do not survive app-kill, so the D17 offline-queue durability budget is not yet exercised, and the string promises "envoyées dès que le réseau revient" while no sender exists. Acceptable inside the preview-banner demo with publication owned by B2.1 — must become a durable queue there.

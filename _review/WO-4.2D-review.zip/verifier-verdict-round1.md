# WO-4.2D fresh-context verifier — round 1 (at 3bdead2), VERBATIM

All evidence is in. The gate script exited 0 ("ALL GATES GREEN"), and my independent harness confirms every mandated attack — except one demonstrated hole in the fail-closed property. Final report.

---

## WO-4.2D ADVERSARIAL VERIFICATION — evidence-grounded report

Everything below was run by me in this session; nothing is taken from the builder's claims.

### Attack 1 — atob deleted, full capture chain (DONE)
Compiled `/home/user/boutik-plus/apps/supplier-app/src/studio/normalization.ts` with the repo's own esbuild (compiled output contains **zero** `atob` references), then in plain node ran `delete globalThis.atob` (verified `typeof atob === 'undefined'`) and executed the full pure chain:
- Clean JPEG (SOI+APP0/JFIF+DQT+SOS) → `base64ToBytes` → bytes byte-identical to fixture → `jpegCarriesExif` false → `assertExifFree` passes. **End-to-end success with no atob.**
- EXIF JPEG (APP1 `Exif\0\0` + TIFF header) → decodes byte-identical → `jpegCarriesExif` true → `assertExifFree` throws `ExifLeakError` with `detail === 'exif_leak'`, and `failureDetailOf` maps it to `'exif_leak'`. **Fail-closed retained for the EXIF attack.**
- `capture.ts:55-58` calls exactly `renderDerivative → base64ToBytes(derivative.base64 ?? '') → assertExifFree(bytes)`; metrics path (line 64) reuses `base64ToBytes`. Grep of `apps/supplier-app/src` for `atob|Buffer|TextDecoder|btoa`: one hit, a comment in normalization.ts:143. Nothing else on the path touches any global decoder.

### Attack 2 — decoder vs reference (DONE; one hole found)
- Byte-identity vs `Buffer.from(b64,'base64')`: both JPEG fixtures padded AND unpadded, plus pseudo-random byte arrays of every length 1–97 (all %4 remainders), padded and unpadded — **all byte-identical**.
- Fail-closed throws `ExifLeakError`/`decode_failed` confirmed for: `''`, `'A'`, `'AAAAB'` (%4==1), `'#'`, `'é'` (>127), embedded space, `'\n'`, `'\r'`, NUL, url-safe `'-'` and `'_'`, interior `'='`. Non-canonical trailing bits (`'AB'`, `'QQ'`, `'999='`) and excessive padding (`'AA========'`) match the reference decoder exactly — no silent divergence there.
- **But**: padding-only input is a silent vacuous pass — see blocker ①.

### Attack 3 — diagnostics leak into non-preview bundle (DONE, clean)
- App.tsx:336 gate is exactly `{IS_PREVIEW && failureDetail !== null && (…)}` — IS_PREVIEW first, member-expression inlinable. `src/preview.ts:17` uses `process.env.EXPO_PUBLIC_PROFILE` dot-access, same as the ratified banner (App.tsx:196).
- Ran compiled `isPreviewProfile('production')` → `false`; `undefined` → `true`; `'preview'` → `true`.
- Whole-app grep for `failureDetail|erreur_detail`: only App.tsx state (118, 152), the ungated plain chip (332), the gated pill (336–339), styles, tests, and the catalog entry. **No ungated render path, no logging of the code.**
- The plain chip `{failureDetail !== null && <StatusChip …t('studio.erreur')…}` (App.tsx:332) is NOT preview-gated — the designed failure state exists in every profile. Correct.

### Also-checked (all confirmed by my own runs/reads)
- **Category expansion creates no policy**: guidance.ts is a pure key map; comment names the open Decision (⏳) as guidance-only; no allow/deny machinery anywhere (comment-stripped grep in the repo test, which I read — it asserts real things).
- **Catalog**: every new category has `categorie.*` + hero/preuve frame-guide keys; all new strings carry register+screenClass. `copy-lint apps/supplier-app/i18n/catalog.json` → **OK, 103 entries, 0 violations** (my run).
- **Camera layout**: read all new styles (App.tsx:594–656) — every value is `flex: 1`, `0`, a `theme.*` token expression (incl. `-theme.spacing.lg` full-bleed matching `content`'s padding token), or `'80%'`. Zero hardcoded colors/dimensions. Banner `top: 0`, capture overlay `bottom: 0` centered, category recall chip present, corners edge-anchored on `absoluteFillObject`. Exactly **one** `PrimaryButton` in the granted-capture block (line 344).
- **Scope**: `git diff main...e4/wo-4.2d --name-only` → 7 files, all under `apps/supplier-app` (App.tsx, WALKTHROUGH.md, catalog.json, guidance.ts, normalization.ts, capture-incident.test.ts new, ui-studio.test.ts 2-assertion rename). **No** package.json, journey.ts, src/demo/, packages/, services, money, or contracts files touched; spine test files untouched.
- **Gates by my own runs**: `pnpm --filter supplier-app test` → **57/57**; `typecheck` clean; `bash scripts/run-gates.sh` → exit 0, "ALL GATES GREEN (positives passed; every negative fixture failed as required)".

---

`VERDICT: FAIL`

**Blockers**

① **Padding-only base64 silently produces zero bytes and the EXIF guard passes vacuously — the diff's own "never a vacuous green light" property is falsified, and it is a strictness REGRESSION vs the code it replaces.** File: `apps/supplier-app/src/studio/normalization.ts:158-163`. The `while` loop strips ALL trailing `'='`, so for input `'='`, `'=='`, `'==='`, `'===='` (nonempty, passes the line-152 empty check) `end` becomes 0, `0 % 4 !== 1`, the loop body never runs, and a **0-length Uint8Array returns without error**. Demonstrated downstream: `jpegCarriesExif(out) === false`, `assertExifFree(out)` **passes** — the guard "proves" EXIF-free on nothing. Concrete scenario: `capture.ts:57` receives `derivative.base64 === '=='` from a corrupted native bridge → WO-4.2C's atob path **threw** (`atob('==')` → InvalidCharacterError, verified in node this session) and refused the capture; WO-4.2D keeps the capture with an unverified derivative. The order's DoD says fail-closed is "retained for genuinely invalid base64"; padding-only is genuinely invalid (both WHATWG forgiving-base64 and strict RFC 4648 reject it), and the repo's own test list (`'', 'A', '####', 'ABéA', 'AAAA A'`) misses this class. One-line fix: after the padding strip, `if (end === 0) throw new ExifLeakError('padding-only base64 …', 'decode_failed')` — plus a test pinning it.

**Non-blockers**

NB① **Whitespace-wrapped base64 now refuses captures that WO-4.2C decoded successfully — a possible recurrence of the founder-visible incident on devices whose encoder wraps lines.** `normalization.ts:167-175` throws `decode_failed` on any `\n`/`\r`/space; the old `atob` path performed WHATWG forgiving decode (verified: `atob('AAAA\nAAAA')` returns 6 chars in node). MIME base64 wraps at 76 columns and Android's `Base64.DEFAULT` inserts `\n`; whether expo-image-manipulator's `saveAsync` ever emits wrapped base64 per platform is UNVERIFIABLE in-sandbox. This fails **closed** (designed state + preview diagnostic naming `decode_failed`), so no invariant is at risk — but recommend stripping ASCII whitespace before decoding (matching forgiving-base64) when fixing ①, and device-matrix evidence on a real Android before founder sign-off.

NB② `failureDetailOf` (`normalization.ts:96`) misses camelcase permission shapes: `new Error('User NotAuthorized for camera')` → `'capture_failed'`, not `'permission'` (regex has only `unauthorized|not authorized`). Preview-only diagnostic, cosmetic; consider adding `not.?authorized`.

Evidence artifacts (mine, outside the repo): `/tmp/claude-0/-home-user/9f5f9ca9-d816-5551-a513-bbf38278fa3b/scratchpad/attack.cjs` (+ compiled `normalization.cjs`, `preview-lib.cjs`); gate-run log at `/tmp/claude-0/-home-user/9f5f9ca9-d816-5551-a513-bbf38278fa3b/tasks/bobym3ec0.output`. No tracked files were modified.
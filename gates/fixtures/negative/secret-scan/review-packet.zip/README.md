NEGATIVE FIXTURE (secret-scan) - a review packet whose log member echoed a key.
